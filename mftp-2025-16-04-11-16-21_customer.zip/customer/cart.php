<?php
session_start();
include '../config/db.php';

$user_id = $_SESSION['user_id'];

// Fetch cart items with images
$cart_query = "SELECT c.*, p.name, p.price, p.image_url FROM cart c JOIN products p ON c.product_id = p.product_id WHERE c.user_id='$user_id'";
$cart_result = $conn->query($cart_query);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Supermart - Cart</title>
    <link rel="stylesheet" href="../assets/style.css"> 
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            text-align: center;
        }
        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
            background: #fff;
            box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
        }
        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        img {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 5px;
        }
        .btn {
            padding: 8px 15px;
            color: white;
            background: #28a745;
            text-decoration: none;
            border-radius: 5px;
            display: inline-block;
            margin-top: 10px;
        }
        .btn-danger {
            background: #dc3545;
        }
    </style>
</head>
<body>
    <h2>Your Cart</h2>
    <a href="home.php">🛒 Continue Shopping</a> | <a href="../auth/logout.php">Logout</a>

    <table>
        <tr>
            <th>Image</th>
            <th>Product</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Total</th>
            <th>Action</th>
        </tr>
        <?php
        $total_price = 0;
        while ($row = $cart_result->fetch_assoc()) {
            $subtotal = $row['price'] * $row['quantity'];
            $total_price += $subtotal;
            ?>
            <tr>
                <td><img src="<?php echo htmlspecialchars($row['image_url']); ?>" alt="Product Image"></td>
                <td><?php echo htmlspecialchars($row['name']); ?></td>
                <td>₹<?php echo htmlspecialchars($row['price']); ?></td>
                <td><?php echo htmlspecialchars($row['quantity']); ?></td>
                <td>₹<?php echo $subtotal; ?></td>
                <td>
                    <form action="remove_from_cart.php" method="post">
                        <input type="hidden" name="product_id" value="<?php echo $row['product_id']; ?>">
                        <input type="hidden" name="quantity" value="<?php echo $row['quantity']; ?>">
                        <button type="submit" class="btn btn-danger">Remove</button>
                    </form>
                </td>
            </tr>
        <?php } ?>
    </table>

    <h3>Cost: ₹<?php echo $total_price; ?></h3>
    <h3>GST + VAT (8%): ₹<?php echo ($total_price * 0.08); ?></h3>
    <h3>Total: ₹<?php echo ($total_price * 0.08) + $total_price; ?></h3>

    <?php if ($total_price > 0) { ?>
        <a href="checkout.php" class="btn">Proceed to Payment</a>
    <?php } else { ?>
        <p>Your cart is empty.</p>
    <?php } ?>
</body>
</html>