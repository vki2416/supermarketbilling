<?php
session_start();
include '../config/db.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

// Fetch products based on category search
$category_filter = "";
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $category_filter = $conn->real_escape_string($_GET['search']);
    $query = "SELECT * FROM products WHERE category LIKE '%$category_filter%'";
} else {
    $query = "SELECT * FROM products";
}

$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Supermart - Home</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 30px;
        }
        .card {
            transition: 0.3s;
        }
        .card:hover {
            transform: scale(1.03);
        }
        .out-of-stock {
            color: red;
            font-weight: bold;
        }
        .product-img {
            width: 100%;
            height: auto;
            max-height: 200px;
            object-fit: cover;
        }
    </style>
</head>
<body>

<div class="container">
    <h2 class="text-center text-primary">Welcome, <?php echo htmlspecialchars($_SESSION['name']); ?>!</h2>

    <div class="d-flex justify-content-between mb-4">
        <a href="cart.php" class="btn btn-success">🛒 View Cart</a>
        <a href="../auth/logout.php" class="btn btn-danger">Logout</a>
    </div>

    <!-- Show error messages -->
    <?php if (isset($_SESSION['error'])) { ?>
        <div class="alert alert-danger"><?php echo $_SESSION['error']; ?></div>
        <?php unset($_SESSION['error']); ?>
    <?php } ?>

    <!-- Search Bar -->
    <form method="GET" class="input-group mb-4">
        <input type="text" name="search" class="form-control" placeholder="Enter category" value="<?php echo htmlspecialchars($category_filter); ?>">
        <button type="submit" class="btn btn-primary">Search</button>
        <a href="home.php" class="btn btn-secondary">Reset</a>
    </form>

    <!-- Product List -->
    <h3 class="text-center">Available Products</h3>
    <div class="row">
        <?php while ($row = $result->fetch_assoc()) { ?>
            <div class="col-md-4 mb-4">
                <div class="card p-3">
                    <!-- Product Image -->
                    <img src="<?php echo htmlspecialchars($row['image_url']); ?>" alt="Product Image" class="product-img mb-3">

                    <h5 class="card-title"><?php echo htmlspecialchars($row['name']); ?></h5>
                    <p><strong>Price:</strong> ₹<?php echo htmlspecialchars($row['price']); ?></p>
                    <p><strong>Category:</strong> <?php echo htmlspecialchars($row['category']); ?></p>
                    <p><strong>Description:</strong> <?php echo htmlspecialchars($row['description']); ?></p>
                    <p><strong>Stock:</strong> 
                        <?php if ($row['stock_quantity'] > 0) { ?>
                            <?php echo htmlspecialchars($row['stock_quantity']); ?>
                        <?php } else { ?>
                            <span class="out-of-stock">Out of stock</span>
                        <?php } ?>
                    </p>
                    <?php if ($row['stock_quantity'] > 0) { ?>
                        <form action="add_to_cart.php" method="post">
                            <input type="hidden" name="product_id" value="<?php echo $row['product_id']; ?>">
                            <input type="number" name="quantity" class="form-control mb-2" value="1" min="1" max="<?php echo $row['stock_quantity']; ?>" required>
                            <button type="submit" class="btn btn-primary w-100">Add to Cart</button>
                        </form>
                    <?php } ?>
                </div>
            </div>
        <?php } ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
