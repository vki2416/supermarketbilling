<?php
session_start();
include '../config/db.php';

$user_id = $_SESSION['user_id'];

// Fetch cart items along with cost_price
$cart_query = "SELECT c.*, p.name, p.price, p.cost_price, p.image_url 
               FROM cart c 
               JOIN products p ON c.product_id = p.product_id 
               WHERE c.user_id='$user_id'";

$cart_result = $conn->query($cart_query);

$total_price = 0;
$total_profit = 0;

$cart_items = []; // Store cart items for display

while ($row = $cart_result->fetch_assoc()) {
    $subtotal = $row['price'] * $row['quantity'];
    $profit = ($row['price'] - $row['cost_price']) * $row['quantity'];
    
    $total_price += $subtotal;
    $total_profit += $profit;

    // Add the item to the cart array
    $cart_items[] = $row;
}

// If form is submitted, redirect to payment gateway
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $_SESSION['payment_method'] = $_POST['payment_method'];
    $_SESSION['total_price'] = $total_price;
    $_SESSION['total_profit'] = $total_profit;
    
    header("Location: payment_gateway.php"); // Redirect to dummy gateway
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 80%;
            margin: 50px auto;
            padding: 20px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: #333;
        }

        .cart-items {
            display: flex;
            flex-direction: column;
            gap: 15px;
            margin-bottom: 20px;
        }

        .cart-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 1px solid #e0e0e0;
            padding-bottom: 10px;
            margin-bottom: 10px;
        }

        .cart-item img {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 8px;
        }

        .cart-item .item-details {
            flex-grow: 1;
            margin-left: 20px;
        }

        .item-details p {
            margin: 5px 0;
            color: #555;
        }

        .total-amount {
            font-size: 18px;
            font-weight: bold;
            color: #2e7d32;
            margin-bottom: 20px;
        }

        select {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            width: 100%;
            margin-bottom: 20px;
            font-size: 16px;
            color: #333;
            background-color: #fff;
        }

        button {
            width: 100%;
            padding: 15px;
            font-size: 18px;
            color: white;
            background-color: #007bff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #0056b3;
        }

        footer {
            text-align: center;
            margin-top: 30px;
            color: #777;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Checkout</h2>

        <!-- Cart Items List -->
        <div class="cart-items">
            <?php foreach ($cart_items as $item): ?>
            <div class="cart-item">
                <img src="<?php echo $item['image_url']; ?>" alt="Product Image">
                <div class="item-details">
                    <p><strong><?php echo $item['name']; ?></strong></p>
                    <p>Price: ₹<?php echo number_format($item['price'], 2); ?></p>
                    <p>Quantity: <?php echo $item['quantity']; ?></p>
                    <p>Subtotal: ₹<?php echo number_format($item['price'] * $item['quantity'], 2); ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- Total Amount -->
        <div class="total-amount">
            <p>Total Amount: ₹<?php echo number_format($total_price, 2); ?></p>
        </div>

        <!-- Payment Form -->
        <form method="POST">
            <label for="payment_method">Select Payment Method:</label>
            <select name="payment_method" required>
                <option value="cash">Cash</option>
                <option value="card">Credit/Debit Card</option>
                <option value="UPI">UPI</option>
            </select>

            <button type="submit">Proceed to Payment</button>
        </form>
    </div>

    <footer>
        <p>&copy; 2025 Supermarket Billing System</p>
    </footer>
</body>
</html>
