<?php
session_start();
include '../config/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    $product_id = $_POST['product_id'];
    $quantity = (int) $_POST['quantity'];

    // Get available stock
    $stock_query = "SELECT stock_quantity FROM products WHERE product_id='$product_id'";
    $stock_result = $conn->query($stock_query);
    $stock_row = $stock_result->fetch_assoc();
    $available_stock = (int) $stock_row['stock_quantity'];

    // Check if stock is enough
    if ($quantity > $available_stock) {
        $_SESSION['error'] = "Only $available_stock items available!";
        header("Location: home.php");
        exit();
    }

    // Deduct stock immediately
    $new_stock = $available_stock - $quantity;
    $update_stock = "UPDATE products SET stock_quantity = $new_stock WHERE product_id='$product_id'";
    $conn->query($update_stock);

    // Add product to cart
    $cart_query = "SELECT quantity FROM cart WHERE user_id='$user_id' AND product_id='$product_id'";
    $cart_result = $conn->query($cart_query);

    if ($cart_result->num_rows > 0) {
        // Update cart quantity
        $update_cart = "UPDATE cart SET quantity = quantity + $quantity WHERE user_id='$user_id' AND product_id='$product_id'";
        $conn->query($update_cart);
    } else {
        // Insert into cart
        $insert_cart = "INSERT INTO cart (user_id, product_id, quantity) VALUES ('$user_id', '$product_id', '$quantity')";
        $conn->query($insert_cart);
    }

    header("Location: home.php");
    exit();
}
?>
